#ifndef VIDEO_H
#define VIDEO_H

#include <QObject>
#include <QVariant>

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <iostream>

#include "Common.h"

class Video : public QObject
{
    Q_OBJECT

public:
    static Video &instance();

    cv::Mat *getImgBuffer();
    std::vector<struct FaceRegion> *getFaceRegion();
    int *getCountUnknown();

public slots:
    void cppSlotStartVideo();
    void cppSlotStopVideo();
    void cppSlotShowImage();

private:
    Video();

    void openWindow();
    void showImage();
    void closeWindow();
    void embedFaceRegionToImage();
    void clearFaceRegion();

    cv::Mat imgBuffer;
    std::vector<struct FaceRegion> faceRegion;
    int countUnknown;
};

#endif // VIDEO_H
