#include "CommData.h"

CommData::CommData()
{
}

CommData &CommData::instance()
{
    static CommData *instance = new CommData();
    return *instance;
}

void CommData::cppSlotStartCommData(QVariant ip, QVariant port, QVariant tls)
{
    std::cout << "cppSlotStartCommData call" << std::endl;

    auto std_str_ip = ip.toString().toStdString();
    auto std_str_port = port.toString().toStdString();

    std::cout << "ip: " << std_str_ip << std::endl;
    std::cout << "port: " << std_str_port << std::endl;

    connect(std_str_ip.c_str(), std_str_port.c_str(), tls == 1);
}

void CommData::cppSlotStopCommData()
{
    std::cout << "cppSlotStopCommData call" << std::endl;

    close();
}

void CommData::cppSlotReadData()
{
    //    std::cout << "cppSlotReadData call" << std::endl;

    readData();
}

bool CommData::readData()
{
    if (ssl != NULL)
    {
        return SSL_TcpRecvFaceData(ssl, TcpConnectedPort, video->getImgBuffer(), video->getFaceRegion(), video->getCountUnknown());
    }
    else
    {
        return TcpRecvFaceData(TcpConnectedPort, video->getImgBuffer(), video->getFaceRegion(), video->getCountUnknown());
    }
}
