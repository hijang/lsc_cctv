#include <QGuiApplication>
#include <QLocale>
#include <QQmlApplicationEngine>
#include <QTranslator>

#include "CommData.h"
#include "CommCtrl.h"
#include "Video.h"

int main(int argc, char *argv[])
{
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif

    QGuiApplication app(argc, argv);

    QTranslator translator;
    const QStringList uiLanguages = QLocale::system().uiLanguages();
    for (const QString &locale : uiLanguages)
    {
        const QString baseName = "qt-test_" + QLocale(locale).name();
        if (translator.load(":/i18n/" + baseName))
        {
            app.installTranslator(&translator);
            break;
        }
    }

    QQmlApplicationEngine engine;
    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(
        &engine, &QQmlApplicationEngine::objectCreated,
        &app, [url](QObject *obj, const QUrl &objUrl)
        {
            if (!obj && url == objUrl)
                QCoreApplication::exit(-1);
        },
        Qt::QueuedConnection);
    engine.load(url);

    QObject *root = engine.rootObjects()[0];

    CommData *commData = &CommData::instance();
    CommCtrl *commCtrl = &CommCtrl::instance();
    Video *video = &Video::instance();

    commData->setVideo(video);
    commCtrl->setVideo(video);

    QObject::connect(root, SIGNAL(qmlSignalStartCommData(QVariant, QVariant, QVariant)), commData, SLOT(cppSlotStartCommData(QVariant, QVariant, QVariant)));
    QObject::connect(root, SIGNAL(qmlSignalStopCommData()), commData, SLOT(cppSlotStopCommData()));
    QObject::connect(root, SIGNAL(qmlSignalReadData()), commData, SLOT(cppSlotReadData()));

    QObject::connect(root, SIGNAL(qmlSignalStartCommCtrl(QVariant, QVariant, QVariant)), commCtrl, SLOT(cppSlotStartCommCtrl(QVariant, QVariant, QVariant)));
    QObject::connect(root, SIGNAL(qmlSignalStopCommCtrl()), commCtrl, SLOT(cppSlotStopCommCtrl()));
    QObject::connect(root, SIGNAL(qmlSignalSendCtrlMode(QVariant)), commCtrl, SLOT(cppSlotSendCtrlMode(QVariant)));
    QObject::connect(root, SIGNAL(qmlSignalSendCtrlRegister(QVariant)), commCtrl, SLOT(cppSlotSendCtrlRegister(QVariant)));

    QObject::connect(root, SIGNAL(qmlSignalStartVideo()), video, SLOT(cppSlotStartVideo()));
    QObject::connect(root, SIGNAL(qmlSignalStopVideo()), video, SLOT(cppSlotStopVideo()));
    QObject::connect(root, SIGNAL(qmlSignalShowImage()), video, SLOT(cppSlotShowImage()));

    return app.exec();
}
